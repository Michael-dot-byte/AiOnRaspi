var searchData=
[
  ['software_20licensing_20and_20legal_20information',['Software Licensing and Legal Information',['../licensing.html',1,'index']]],
  ['sample_20code',['Sample Code',['../sample_code.html',1,'index']]]
];
