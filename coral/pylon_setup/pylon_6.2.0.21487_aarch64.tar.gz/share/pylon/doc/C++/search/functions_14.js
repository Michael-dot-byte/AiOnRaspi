var searchData=
[
  ['versioninfo',['VersionInfo',['../class_pylon_1_1_version_info.html#aa412024ebb8588c63bf754c0e0f25222',1,'Pylon::VersionInfo::VersionInfo(bool checkBuild=false)'],['../class_pylon_1_1_version_info.html#a55b1272b734adda15b9196d199626202',1,'Pylon::VersionInfo::VersionInfo(unsigned int major, unsigned int minor, unsigned int subminor)'],['../class_pylon_1_1_version_info.html#a1da56552958f5b08e2d60ebfb1d91c88',1,'Pylon::VersionInfo::VersionInfo(unsigned int major, unsigned int minor, unsigned int subminor, unsigned int build)']]]
];
