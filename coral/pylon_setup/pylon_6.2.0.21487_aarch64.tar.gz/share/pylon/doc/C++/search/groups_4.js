var searchData=
[
  ['universal_20instant_20camera_20for_20all_20basler_20devices',['Universal Instant Camera for All Basler Devices',['../group___pylon___instant_camera_api_universal.html',1,'']]]
];
